<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
  <title>barang</title>
</head>
<body>
  <nav class="navbar navbar-expand-lg navbar-light bg-warning">
    <div class="container-fluid">
      <a class="navbar-brand h1" href=<?php echo e(route('barang.index')); ?>>CRUDbarang</a>
      <div class="justify-end ">
        <div class="col ">
          <a class="btn btn-sm btn-success" href=<?php echo e(route('barang.create')); ?>>Add Post</a>
        </div>
      </div>
    </div>
  </nav>
  <div class="container mt-5">
    
    <table id="datatablesSimple">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama</th>
                <th>Jenis</th>
                
            </tr>
        </thead>
        <tfoot>
            <tr>
                <th>No</th>
                <th>Nama</th>
                <th>Jenis</th>
               
            </tr>
        </tfoot>
        <tbody>
            <?php $__currentLoopData = $barangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($barang->kode_barang); ?></td>
                <td><?php echo e($barang->nama_barang); ?></td>
                <td><?php echo e($barang->jumlah); ?></td>
                
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
  </div>
</body>
</html><?php /**PATH /var/www/app/resources/views/barang/index.blade.php ENDPATH**/ ?>